-- MySQL dump 10.13  Distrib 8.0.23, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: final_project
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `players` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dob` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5nglidr00c4dyybl171v6kask` (`team_id`),
  CONSTRAINT `FK5nglidr00c4dyybl171v6kask` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (21,'May 27, 1997','dantheman@aol.com','Daniel','Jones','abc123','QB','dannyj',23),(22,'November 3, 1993','gollyGK@nygiants.com','Kenny','Golladay','abcdefg','WR','gollyg123',23),(23,'February 9, 1997','saquoniscool4321@gmail.com','Saquon','Barkley','secretpass','RB','sbarkley100',23),(24,'January 7, 1997','lamar.j@ravens.com','Lamar','Jackson','iamgood455','QB','JDot9',24),(25,'June 14, 1993','sammywats@gmai.com','Sammy','Watkins','helloolleh','WR','sammywats',24),(26,'May 11, 1989','camnewt@aol.com','Cam','Newton','hihihihibyehibye','QB','camtheman',25),(27,'December 7, 1994','hhenry@gmai.com','Hunter','Henry','p@ssw0rd','TE','thehunt42',25),(28,'December 2, 1983','rodgy.a@godaddy.com','Aaron','Rodgers','zyxwvuabc','QB','aarodg111',26),(30,'November 2, 1994','tflax@gmail.com','Tom','Flacco','ihatemylife','QB','iWishIWasMyBrother99',27),(31,'November 7, 1995','vdiggs@aol.com','Vontae','Diggs','abc123aaa111','MLB','vincestaplesdoppleganger',28),(32,'October 23, 1985','whyte.s@gmail.com','Sean','Whyte','fadsfsad','K','whytes',28),(33,'January 25, 1985 ','mightymike@gmail.com','Mike','Reilly','mightyducks2','QB','mightymike1',29),(34,'October 17, 1994','jboy@aol.com','Johnathan','Alston','alstonisinboston','CB','alstonjohnny',30),(35,'June 14,1995','jsummers@aol.com','Jamar','Summers','abc12aaadd','FS','jsumsgotthebuns',31),(36,'October 5, 1992','marquise.williams@gmail.com','Marquise','Williams','bushdid912','QB','marqueryiese',31);
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-27 18:52:10
