package com.example.springtemplate.daos;

import com.example.springtemplate.models.Player;
import com.example.springtemplate.models.Team;
import com.example.springtemplate.repositories.PlayerRepository;
import com.example.springtemplate.repositories.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class PlayerOrmDao {
    @Autowired
    PlayerRepository playerRepository;

    @Autowired
    TeamRepository teamRepository;

    @PostMapping("/api/players")
    public Player createPlayer(@RequestBody Player player) {
        return playerRepository.save(player);
    }


    @PostMapping("/api/teams/{teamId}/players")
    public Player createPlayerForTeam(
            @PathVariable("teamId") Integer tid,
            @RequestBody Player player) {
        player = playerRepository.save(player);
        Team team = teamRepository.findById(tid).get();
        player.setTeam(team);
        return playerRepository.save(player);
    }

    @GetMapping("/api/teams/{tid}/players")
    public List<Player> findPlayersForTeam(
            @PathVariable("tid") Integer teamId) {
        Team team = teamRepository.findById(teamId).get();
        return team.getPlayers();
    }

    @GetMapping("/api/players")
    public List<Player> findAllPlayers() {
        return playerRepository.findAllPlayers();
    }
    
    @GetMapping("/api/players/{playerId}")
    public Player findPlayerById(
            @PathVariable("playerId") Integer id) {
        return playerRepository.findPlayerById(id);
    }
    
    @PutMapping("/api/players/{playerId}")
    public Player updatePlayer(
            @PathVariable("playerId") Integer id,
            @RequestBody Player playerUpdates) {
        Player player = this.findPlayerById(id);
        player.setFirstName(playerUpdates.getFirstName());
        player.setLastName(playerUpdates.getLastName());
        player.setUsername(playerUpdates.getUsername());
        player.setPassword(playerUpdates.getPassword());
        player.setEmail(playerUpdates.getEmail());
        player.setDob(playerUpdates.getDob());
       // player.setTeam(playerUpdates.getTeam());
        player.setPosition(playerUpdates.getPosition());
        // may need to set stats field

        return playerRepository.save(player);
    }
    
    @DeleteMapping("/api/players/{playerId}")
    public void deletePlayer(
            @PathVariable("playerId") Integer id) {
        playerRepository.deleteById(id);
    }
}