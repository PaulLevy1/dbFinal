package com.example.springtemplate.daos;

import com.example.springtemplate.models.League;
import com.example.springtemplate.models.Player;
import com.example.springtemplate.models.Team;
import com.example.springtemplate.repositories.LeagueRepository;
import com.example.springtemplate.repositories.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class TeamOrmDao {
    @Autowired
    TeamRepository teamRepository;

    @Autowired
    LeagueRepository leagueRepository;

    @PostMapping("/api/teams")
    public Team createTeam(@RequestBody Team team) {
        return teamRepository.save(team);
    }

    @PostMapping("/api/leagues/{leagueId}/teams")
    public Team createTeamForLeague(
            @PathVariable("leagueId") Integer lid,
            @RequestBody Team team) {
        team = teamRepository.save(team);
        League league = leagueRepository.findById(lid).get();
        team.setLeague(league);
        return teamRepository.save(team);
    }

    @GetMapping("/api/leagues/{lid}/teams")
    public List<Team> findTeamsForLeague(
            @PathVariable("lid") Integer lid) {
        League league = leagueRepository.findById(lid).get();
        return league.getTeams();
    }

    @GetMapping("/api/teams")
    public List<Team> findAllTeams() {
        return teamRepository.findAllTeams();
    }
    
    @GetMapping("/api/teams/{teamId}")
    public Team findTeamById(
            @PathVariable("teamId") Integer id) {
        return teamRepository.findTeamById(id);
    }
    
    @PutMapping("/api/teams/{teamId}")
    public Team updateTeam(
            @PathVariable("teamId") Integer id,
            @RequestBody Team teamUpdates) {
        Team team = this.findTeamById(id);
        team.setCity(teamUpdates.getCity());
        team.setName(teamUpdates.getName());
        team.setWins(teamUpdates.getWins());
        team.setLosses(teamUpdates.getLosses());
        team.setStadium(teamUpdates.getStadium());
        //team.setLeague(teamUpdates.getLeague());
        team.setPlayers(teamUpdates.getPlayers());
        return teamRepository.save(team);
    }
    
    @DeleteMapping("/api/teams/{teamId}")
    public void deleteTeam(
            @PathVariable("teamId") Integer id) {
        teamRepository.deleteById(id);
    }
}