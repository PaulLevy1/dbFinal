package com.example.springtemplate.daos;

import com.example.springtemplate.models.League;
import com.example.springtemplate.repositories.LeagueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class LeagueOrmDao {
    @Autowired
    LeagueRepository leagueRepository;

    @PostMapping("/api/leagues")
    public League createLeague(@RequestBody League league) {
        return leagueRepository.save(league);
    }
    
    @GetMapping("/api/leagues")
    public List<League> findAllLeagues() {
        return leagueRepository.findAllLeagues();
    }
    
    @GetMapping("/api/leagues/{leagueId}")
    public League findLeagueById(
            @PathVariable("leagueId") Integer id) {
        return leagueRepository.findLeagueById(id);
    }
    
    @PutMapping("/api/leagues/{leagueId}")
    public League updateLeague(
            @PathVariable("leagueId") Integer id,
            @RequestBody League leagueUpdate) {
        League league = leagueRepository.findLeagueById(id);
        league.setCommissioner(leagueUpdate.getCommissioner());
        league.setName(leagueUpdate.getName());
        league.setTeams(leagueUpdate.getTeams());
        return leagueRepository.save(league);
    }
    
    @DeleteMapping("/api/leagues/{leagueId}")
    public void deleteLeague(
            @PathVariable("leagueId") Integer id) {
        leagueRepository.deleteById(id);
    }
}