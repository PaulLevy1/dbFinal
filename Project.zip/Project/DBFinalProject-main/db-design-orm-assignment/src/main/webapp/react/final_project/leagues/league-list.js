import LeagueEditorInline from "./league-editor-inline";
import LeagueService from "./league-service"
import PlayerList from "../players/player-list"
import TeamList from "../teams/team-list"


const LEAGUE_URL = "http://localhost:8080/api/leagues"
const { useState, useEffect } = React;
const {Link} = window.ReactRouterDOM;

const LeagueList = () => {
    const [leagues, setLeagues] = useState([])
    const [newLeague, setNewLeague] = useState({})
    useEffect(() => {
        findAllLeagues()
    }, [])
    const createLeague = (league) =>
        leagueService.createLeague(league)
            .then(league => {
                setNewLeague({name:'',commissioner:''})
                setLeagues(leagues => ([...leagues, league]))
            })
    const updateLeague = (id, newLeague) =>
        leagueService.updateLeague(id, newLeague)
            .then(league => setLeagues(leagues => (leagues.map(league => league.id === id ? newLeague : league))))
    const findAllLeagues = () =>
        leagueService.findAllLeagues()
            .then(leagues => setLeagues(leagues))
    const deleteLeague = (id) =>
        leagueService.deleteLeague(id)
            .then(leagues => setLeagues(leagues => leagues.filter(league => league.id !== id)))
    return(
        <div>
            <h2>Leagues</h2>
            <ul className="list-group">
                <li className="list-group-item">
                    <div className="row">
                        <div className="col">
                            <input placeholder="League Name"
                                   title="Please enter a name for the league" className="form-control" value={newLeague.name}
                                   onChange={(e) => setNewLeague(newLeague => ({...newLeague, name: e.target.value}))}/>
                        </div>
                        <div className="col">
                            <input placeholder="League Commissioner"
                                   title="Please enter a commissioner for the league" className="form-control" value={newLeague.commissioner}
                                   onChange={(e) => setNewLeague(newLeague => ({...newLeague, commissioner: e.target.value}))}/>
                        </div>
                        <div className="col-3">
                            <i className="fas fa-plus fa-2x float-right" onClick={() => createLeague(newLeague)}></i>
                        </div>
                    </div>
                </li>
            {
                leagues.map(league =>
                    <li key={league.id} className="list-group-item">
                        <LeagueEditorInline key={league._id}
                            updateLeague={updateLeague}
                            deleteLeague={deleteLeague}
                            league={league}/>
                    </li>)
            }
            </ul>
        </div>
    )
}

export default LeagueList;