const {useState, useEffect } = React;
const {Link} = window.ReactRouterDOM;

const PlayerEditorInline = ({player, deletePlayer, updatePlayer}) => {
    const [playerCopy, setPlayerCopy] = useState(player)
    const [editing, setEditing] = useState(false)
    return(
        <div>
            {
                editing &&
                <div className="row">
                    <div className="col">
                        <input
                            className="form-control"
                            value={playerCopy.firstName}
                            onChange={(e)=>setPlayerCopy(playerCopy => ({...playerCopy, firstName: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={playerCopy.lastName}
                            onChange={(e)=>setPlayerCopy(playerCopy => ({...playerCopy, lastName: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <select
                            className="form-control"
                            value={playerCopy.position}
                            onChange={(e)=>setPlayerCopy(playerCopy => ({...playerCopy, position: e.target.value}))}>
                            <option>QB</option>
                            <option>RB</option>
                            <option>FB</option>
                            <option>WR</option>
                            <option>TE</option>
                            <option>LT</option>
                            <option>LG</option>
                            <option>C</option>
                            <option>RG</option>
                            <option>RT</option>
                            <option>LE</option>
                            <option>DT</option>
                            <option>RE</option>
                            <option>LOLB</option>
                            <option>MLB</option>
                            <option>ROLB</option>
                            <option>CB</option>
                            <option>FS</option>
                            <option>SS</option>
                            <option>K</option>
                            <option>P</option>
                        </select>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={playerCopy.team}
                            onChange={(e)=>setPlayerCopy(playerCopy => ({...playerCopy, team: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={playerCopy.dob}
                            onChange={(e)=>setPlayerCopy(playerCopy => ({...playerCopy, dob: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={playerCopy.email}
                            onChange={(e)=>setPlayerCopy(playerCopy => ({...playerCopy, email: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={playerCopy.username}
                            onChange={(e)=>setPlayerCopy(playerCopy => ({...playerCopy, username: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={playerCopy.password}
                            onChange={(e)=>setPlayerCopy(playerCopy => ({...playerCopy, password: e.target.value}))}/>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-2x fa-check float-right margin-left-10px"
                           onClick={() => {
                               setEditing(false)
                               updatePlayer(playerCopy.id, playerCopy)
                           }}></i>
                        <i className="fas fa-2x fa-undo float-right margin-left-10px"
                           onClick={() => setEditing(false)}></i>
                        <i className="fas fa-2x fa-trash float-right margin-left-10px"
                           onClick={() => deletePlayer(player.id)}></i>
                    </div>
                </div>
            }
            {
                !editing &&
                <div className="row">
                    <div className="col">
                        <Link to={`/players/${playerCopy.id}`}>
                            {playerCopy.firstName}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/players/${playerCopy.id}`}>
                            {playerCopy.lastName}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/players/${playerCopy.id}`}>
                            {playerCopy.position}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/players/${playerCopy.id}`}>
                            {playerCopy.dob}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/players/${playerCopy.id}`}>
                            {playerCopy.team}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/players/${playerCopy.id}`}>
                            {playerCopy.email}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/players/${playerCopy.id}`}>
                            {playerCopy.username}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/players/${playerCopy.id}`}>
                            {playerCopy.password}
                        </Link>
                    </div>

                    <div className="col-1">
                        <i className="fas fa-cog fa-2x float-right"
                           onClick={() => setEditing(true)}></i>
                    </div>
                </div>
            }
        </div>
    )
}

export default PlayerEditorInline;