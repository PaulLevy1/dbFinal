import Players from "./players";
import PlayerList from "./players/player-list";
import PlayerFormEditor from "./players/player-form-editor";
import TeamList from "./teams/team-list";
import TeamFormEditor from "./teams/team-form-editor";
import LeagueList from "./leagues/league-list";
import LeagueFormEditor from "./leagues/league-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
    return (
        <div>
            <HashRouter>

                <Route path={["/players", "/"]} exact={true}>
                    <PlayerList/>
                </Route>

                <Route path="/players/:id" exact={true}>
                    <PlayerFormEditor/>
                </Route>

                <Route path={["/teams", "/"]} exact={true}>
                    <TeamList/>
                </Route>

                <Route path="/teams/:id" exact={true}>
                    <TeamFormEditor/>
                </Route>

                <Route path={["/leagues", "/"]} exact={true}>
                    <LeagueList/>
                </Route>

                <Route path="/leagues/:id" exact={true}>
                    <LeagueFormEditor/>
                </Route>

                <Route path={["/teams"]} exact={true}>
                    <TeamList/>
                </Route>
                <Route path={["/players"]} exact={true}>
                    <PlayerList/>
                </Route>

            </HashRouter>
        </div>
    );
}
export default App;