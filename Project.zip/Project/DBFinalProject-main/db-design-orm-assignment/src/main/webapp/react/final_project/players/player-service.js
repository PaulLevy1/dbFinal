const TEAM_URL = "http://localhost:8080/api/teams"
const PLAYER_URL = "http://localhost:8080/api/players"

export const createPlayerForTeam = (teamId, player) =>
    fetch(`${TEAM_URL}/${teamId}/players`, {
        method: 'POST',
        body: JSON.stringify(player),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export const findPlayersForTeam = (teamId) =>
    fetch(`${TEAM_URL}/${teamId}/players`)
        .then(response => response.json())

export const findPlayerById = (id) =>
    fetch(`${PLAYER_URL}/${id}`)
        .then(response => response.json())

export const updatePlayer = (id, player) =>
    fetch(`${PLAYER_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(player),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

const deletePlayer = (id) =>
    fetch(`${PLAYER_URL}/${id}`, {
        method: "DELETE"
    })

export default {
    createPlayerForTeam,
    findPlayersForTeam,
    findPlayerById,
    updatePlayer,
    deletePlayer
}