const TEAM_URL = "http://localhost:8080/api/teams"
const LEAGUE_URL = "http://localhost:8080/api/leagues"

export const createTeamForLeague = (leagueId,team) =>
    fetch(`${LEAGUE_URL}/${leagueId}/teams`, {
        method: 'POST',
        body: JSON.stringify(team),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export const findTeamsForLeague = (leagueId) =>
    fetch(`${LEAGUE_URL}/${leagueId}/teams`)
        .then(response => response.json())

export const findAllTeams = () =>
    fetch(TEAM_URL)
        .then(response => response.json())

export const findTeamById = (id) =>
    fetch(`${TEAM_URL}/${id}`)
        .then(response => response.json())

export const updateTeam = (id, team) =>
    fetch(`${TEAM_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(team),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export const deleteTeam = (id) =>
    fetch(`${TEAM_URL}/${id}`, {
        method: "DELETE"
    })

export default {
    createTeamForLeague,
    findTeamsForLeague,
    findAllTeams,
    findTeamById,
    updateTeam,
    deleteTeam
}