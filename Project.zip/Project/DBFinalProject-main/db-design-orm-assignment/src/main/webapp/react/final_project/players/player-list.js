import PlayerEditorInline from "./player-editor-inline";
import playerService, {createPlayerForTeam} from "./player-service"

const TEAM_URL = "http://localhost:8080/api/players"
const { useState, useEffect } = React;
const {Link, useParams, useHistory} = window.ReactRouterDOM;

const PlayerList = () => {
    const [players, setPlayers] = useState([])
    const [newPlayer, setNewPlayer] = useState({})
    const {teamId} = useParams()
    useEffect(() => {
        findPlayersForTeam(teamId)
    }, [])
    const createPlayerForTeam = (player) =>
        playerService.createPlayerForTeam(teamId, player)
            .then(player => {
                setNewPlayer({firstName:'',lastName:''})
                setPlayers(players => ([...players, player]))
            })
    const updatePlayer = (id, newPlayer) =>
        playerService.updatePlayer(id, newPlayer)
            .then(player => setPlayers(players => (players.map(player => player.id === id ? newPlayer : player))))
    const findPlayersForTeam = (teamId) =>
        playerService.findPlayersForTeam(teamId)
            .then(players => setPlayers(players))
    const deletePlayer = (id) =>
        playerService.deletePlayer(id)
            .then(players => setPlayers(players => players.filter(player => player.id !== id)))
    return(
        <div>
            <h2>
                <Link onClick={() => history.back()}>
                    <i className="fas fa-arrow-left margin-right-10px"></i>
                </Link>
                Players
            </h2>
            <ul className="list-group">
                <li className="list-group-item">
                    <div className="row">
                        <div className="col">
                            <input placeholder="First Name"
                                   title="Please enter a first name for the player"
                                   className="form-control"
                                   value={newPlayer.title}
                                   onChange={(e) => setNewPlayer(newPlayer => ({...newPlayer, firstName: e.target.value}))}/>
                        </div>
                        <div className="col">
                            <input placeholder="Last Name"
                                   title="Please enter a last name for the player"
                                   className="form-control"
                                   value={newPlayer.title}
                                   onChange={(e) => setNewPlayer(newPlayer => ({...newPlayer, lastName: e.target.value}))}/>
                        </div>
                        <div className="col-2">
                            <i className="fas float-right fa-plus fa-2x"
                                onClick={() => createPlayerForTeam(newPlayer)}></i>
                        </div>
                    </div>
                </li>
            {
                players.map(player =>
                    <li key={player.id} className="list-group-item">
                        <PlayerEditorInline key={player._id}
                                             updatePlayer={updatePlayer}
                                             deletePlayer={deletePlayer}
                                             player={player}/>
                    </li>)
            }
            </ul>
        </div>
    )
}

export default PlayerList;