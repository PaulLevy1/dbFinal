import LeagueService from "./league-service"
import PlayerService

const LEAGUE_URL = "http://localhost:8080/api/leagues"
const { useState, useEffect } = React;

const HomeList = () => {
    const [leagues, setLeagues] = useState([])
    const [newLeague, setNewLeague] = useState({})
    useEffect(() => {
        findAllLeagues()
    }, [])
    const createLeague = (league) =>
        leagueService.createLeague(league)
            .then(league => {
                setNewLeague({name:'',commissioner:''})
                setLeagues(leagues => ([...leagues, league]))
            })
    const updateLeague = (id, newLeague) =>
        leagueService.updateLeague(id, newLeague)
            .then(league => setLeagues(leagues => (leagues.map(league => league.id === id ? newLeague : league))))
    const findAllLeagues = () =>
        leagueService.findAllLeagues()
            .then(leagues => setLeagues(leagues))
    const deleteLeague = (id) =>
        leagueService.deleteLeague(id)
            .then(leagues => setLeagues(leagues => leagues.filter(league => league.id !== id)))
    return(
        <div>
            <h2>Leagues</h2>
            <ul className="list-group">

            {
                leagues.map(league =>
                    <li key={league.id} className="list-group-item">
                        <LeagueEditorInline key={league._id}
                            updateLeague={updateLeague}
                            deleteLeague={deleteLeague}
                            league={league}/>
                    </li>)
            }
            </ul>
        </div>
        <div className="row">
            <Link to={`/players`}>
                {"Players"}
            </Link>
        </div>
        <div className="row">
            <Link to={`/teams`}>
                {"Teams"}
            </Link>
        </div>
    )
}

export default LeagueList;

{
                !editing &&
                <div className="row">
                    <div className="col">
                        <Link to={`/leagues/${league.id}`}>
                            {league.name}
                        </Link>
                    </div>
                </div>
            }