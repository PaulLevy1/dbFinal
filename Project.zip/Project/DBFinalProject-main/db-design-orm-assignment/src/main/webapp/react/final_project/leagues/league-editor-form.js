import Service from "./league-service"

const {useState, useEffect} = React
const {useParams, useHistory} = window.ReactRouterDOM;
const LEAGUE_URL = "http://localhost:8080/api/leagues"

const LeagueEditorForm = () => {
    const [league, setLeague] = useState({})
    const {id} = useParams()
    const history = useHistory()
    useEffect(() => {
        findLeagueById(id)
    }, []);
    const findLeagueById = (id) =>
        leagueService.findLeagueById(id)
            .then(league => setLeague(league))
    const updateLeague = (id, newLeague) =>
        leagueService.updateLeague(id, newLeague)
            .then(() => history.goBack())
    const deleteLeague = (id) =>
        leagueService.deleteLeague(id)
            .then(() => history.goBack())
    
    return (
        <div>
            <h2>
                League Editor
            </h2>
            <label>Id</label>
            <input
                className="form-control margin-bottom-10px"
                readOnly={true}
                value={league.id}/>
            <label>Name</label>
                       <input
                           className="form-control margin-bottom-10px"
                           onChange={(e) => setLeague(league => ({...league, name: e.target.value}))}
                           value={league.name}/>
            <label>Commissioner</label>
            <input
                className="form-control margin-bottom-10px"
                onChange={(e) => setLeague(league => ({...league, commissioner: e.target.value}))}
                value={league.commissioner}/>

            <button
                onClick={() => updateLeagues(league.id, league)}
                className="btn btn-success btn-block">Save</button>
            <button
                onClick={() => {
                    history.goBack()
                }}
                className="btn btn-danger btn-block margin-left-10px">Cancel</button>
            <button
                onClick={() => deleteLeague(league.id)}
                className="btn btn-danger btn-block margin-left-10px">Delete</button>
        </div>
    )
}

export default LeagueEditorForm