import PlayerList from "./players/player-list";
import TeamList from "./teams/team-list";
import PlayerEditorForm from "./players/player-editor-form";
import TeamEditorForm from "./teams/team-editor-form";
import LeagueList from "./leagues/league-list";
import LeagueEditorForm from "./leagues/league-editor-form";

const {HashRouter, Link, Route} = window.ReactRouterDOM;
 
const App = () => {
    console.log(window.ReactRouterDOM)
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path="/leagues/:leagueId/teams" exact={true}>
                    <TeamList/>
                </Route>
                <Route path="/teams/:id" exact={true}>
                    <TeamEditorForm/>
                </Route>
                <Route path="/teams/:teamId/players" exact={true}>
                    <PlayerList/>
                </Route>

                <Route path="/players/:playerId" exact={true}>
                    <PlayerEditorForm/>
                </Route>

                <Route path={["/leagues", "/"]} exact={true}>
                    <LeagueList/>
                </Route>
                <Route path="/leagues/:id" exact={true}>
                    <LeagueEditorForm/>
                </Route>
                <Route path={["/teams"]} exact={true}>
                    <TeamList/>
                </Route>
                <Route path={["/players"]} exact={true}>
                    <PlayerList/>
                </Route>

            </HashRouter>
        </div>
    );
}

export default App;
