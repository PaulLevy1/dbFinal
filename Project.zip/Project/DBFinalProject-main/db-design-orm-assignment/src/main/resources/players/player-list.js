const {Link,useHistory} = window.ReactRouterDOM;
import playerService from "./player-service"
const { useState, useEffect } = React;
const PlayerList = () => {
    const [players, setPlayers] = useState([])
    useEffect(() => {
        findAllPlayers()
    }, [])
    const findAllPlayers = () =>
       playerService.findAllPlayers()
            .then(players => setPlayers(players))
    return(
        <div>
            <h2>Player List</h2>
             <button onClick={() => history.push("/players/new")}>
                Add Player
             </button>
            <ul className="list-group">
                 {
                    players.map(player =>
                        <li key={player.id}>
                          <Link to={`/players/${player.id}`}>
                            {player.firstName},
                            {player.lastName},
                            {player.username}
                           </Link>
                        </li>)
                 }
            </ul>
        </div>
    )
}

export default PlayerList;