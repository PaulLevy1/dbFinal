// TODO: declare URL where server listens for HTTP requests
const PLAYERS_URL = "http://localhost:8080/api/players"
const TEAMS_URL = "http://localhost:8080/api/teams"

// TODO: retrieve all players from the server
export const findAllPlayers = () =>
    fetch(PLAYERS_URL)
        .then(response => response.json())

// TODO: find all players for a specific team
export const findPlayersForTeam = (teamId) =>
    fetch(`${TEAMS_URL}/${teamId}/players`)
        .then(response => response.json())

// TODO: retrieve a single player by their ID
export const findPlayerById = (id) =>
    fetch(`${PLAYERS_URL}/${id}`)
        .then(response => response.json())


// TODO: delete a Player by their ID
export const deletePlayer = (id) =>
    fetch(`${PLAYERS_URL}/${id}`, {
        method: "DELETE"
    })

// TODO: create a new player
export const createPlayer = (player) =>
    fetch(`${TEAMS_URL}/${teamId}/players`, {
        method: 'POST',
        body: JSON.stringify(player),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())


// TODO: update a player by their ID
export const updatePlayer = (id, player) =>
    fetch(`${PLAYERS_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(player),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())


// TODO: export all functions as the API to this service
export default {
    findAllPlayers
    findPlayerById
    deletePlayer
    createPlayer
    updatePlayer
}
