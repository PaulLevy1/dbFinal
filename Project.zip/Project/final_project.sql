-- create leagues table
DROP TABLE if EXISTS `final_project`.`leagues`;
CREATE TABLE `final_project`.`leagues` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(45) DEFAULT NULL,
    `commissioner` VARCHAR(45) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

-- create teams table
DROP TABLE if EXISTS `final_project`.`teams`;
CREATE TABLE `final_project`.`teams` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
    `city` VARCHAR(50) DEFAULT NULL,
    `name` VARCHAR(30) DEFAULT NULL,
    `wins` int(1) DEFAULT 0,
    `losses` int(1) DEFAULT 0,
--    `stadium` int(11) DEFAULT NULL,
	`stadium` VARCHAR(50) DEFAULT NULL,
    `league_id` int(11) DEFAULT NULL,
--    `stats` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`),
--    FOREIGN KEY (`stadium`) REFERENCES `final_project`.`stadiums`(`id`),
    FOREIGN KEY (`league_id`) REFERENCES `final_project`.`leagues`(`id`)
--    FOREIGN KEY (`stats`) REFERENCES `final_project`.`stats`(`id`)
);

-- create stadiums table
DROP TABLE if EXISTS `final_project`.`stadiums`;
CREATE TABLE `final_project`.`stadiums` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(45) DEFAULT NULL,
    `address` VARCHAR(80) DEFAULT NULL,
    `capacity` int(8) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

-- create stats table
DROP TABLE if EXISTS `final_project`.`stats`;
CREATE TABLE `final_project`.`stats` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
    `PYDS` float(2) DEFAULT 0,
    `PTDS` int(1) DEFAULT 0,
    `CMP%` float(1) DEFAULT 0,
    `RYDS` float(2) DEFAULT 0,
    `RTDS` int(1) DEFAULT 0,
    `REC`  int(1) DEFAULT 0,
    `TGT`  int(1) DEFAULT 0,
    `WTDS` int(1) DEFAULT 0,
    `WYDS` float(2) DEFAULT 0,
    `FUM`  int(1) DEFAULT 0,
    `TACK` int(2) DEFAULT 0,
    `SACK` int(2) DEFAULT 0,
    `INT`  int(2) DEFAULT 0,
    `DTD`  int(2) DEFAULT 0,
    `FF`   int(1) DEFAULT 0,
    PRIMARY KEY (`id`)
);

CREATE TABLE role (
 		name varchar(20) DEFAULT NULL,
  PRIMARY KEY (name));
INSERT INTO `final_project`.`role` (`name`) VALUES('Manager');
INSERT INTO `final_project`.`role` (`name`) VALUES('Coach');
INSERT INTO `final_project`.`role` (`name`) VALUES('Scout');
INSERT INTO `final_project`.`role` (`name`) VALUES('Medic');


-- create staff table
DROP TABLE IF EXISTS `final_project`.`staff`;
CREATE TABLE `final_project`.`staff` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(45) NULL,
	`role` varchar(20) DEFAULT NULL,
	`salary` INT NOT NULL,
    `team` int(11) NOT NULL,
	PRIMARY KEY (`id`),
	FOREIGN KEY (`team`) REFERENCES `final_project`.`teams` (`id`),
    FOREIGN KEY (`role`) REFERENCES `final_project`.`role`(`name`)
);



CREATE TABLE `final_project`.`position` (
 		name varchar(20) DEFAULT NULL,
  PRIMARY KEY (name));
INSERT INTO `final_project`.`position` (`name`) VALUES('C');
INSERT INTO `final_project`.`position` (`name`) VALUES('OG');
INSERT INTO `final_project`.`position` (`name`) VALUES('OT');
INSERT INTO `final_project`.`position` (`name`) VALUES('QB');
INSERT INTO `final_project`.`position` (`name`) VALUES('RB');
INSERT INTO `final_project`.`position` (`name`) VALUES('WR');
INSERT INTO `final_project`.`position` (`name`) VALUES('TE');
INSERT INTO `final_project`.`position` (`name`) VALUES('DT');
INSERT INTO `final_project`.`position` (`name`) VALUES('DE');
INSERT INTO `final_project`.`position` (`name`) VALUES('MLB');
INSERT INTO `final_project`.`position` (`name`) VALUES('OLB');
INSERT INTO `final_project`.`position` (`name`) VALUES('CB');
INSERT INTO `final_project`.`position` (`name`) VALUES('S');
INSERT INTO `final_project`.`position` (`name`) VALUES('K');


-- create players table
DROP TABLE IF EXISTS `final_project`.`players`;
CREATE TABLE `final_project`.`players` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`first_name` VARCHAR(45) NULL,
	`last_name` VARCHAR(45) NULL,
	`position` varchar(20) DEFAULT NULL,
	`dob` DATE NOT NULL,
    `team_id` int(11) DEFAULT NULL,
    `email` VARCHAR(45) DEFAULT NULL,
    `username` VARCHAR(45) DEFAULT NULL,
    `password` VARCHAR(45) DEFAULT NULL,
--    `stats` int(11) DEFAULT NULL,
	PRIMARY KEY (`id`),
	FOREIGN KEY (`team_id`) REFERENCES `final_project`.`teams` (`id`)
);
    
-- insert data into leagues table

INSERT INTO `final_project`.`leagues` (`name`, `commissioner`)
VALUES ('National Football League', 'Roger Goodell');

INSERT INTO `final_project`.`leagues` (`name`, `commissioner`)
VALUES ('Canadian Football League', 'Randy Ambrosie');

INSERT INTO `final_project`.`leagues` (`name`, `commissioner`)
VALUES ('XFL', 'Oliver Luck');

-- insert data into stadiums

INSERT INTO `final_project`.`stadiums` (`name`, `address`, `capacity`)
VALUES ('Metlife Stadium', '1 MetLife Stadium Dr, East Rutherford, NJ 07073', 82500);

INSERT INTO `final_project`.`stadiums` (`name`, `address`, `capacity`)
VALUES ('BC Place', '777 Pacific Blvd, Vancouver, BC V6B 4Y8, Canada', 54500);

INSERT INTO `final_project`.`stadiums` (`name`, `address`, `capacity`)
VALUES ('Arrowhead Stadium', '1 Arrowhead Dr, Kansas City, MO 64129', 76416);

INSERT INTO `final_project`.`stadiums` (`name`, `address`, `capacity`)
VALUES ('Lumen Field', '800 Occidental Avenue South, Seattle, WA', 68740);

-- insert data into teams

INSERT INTO `final_project`.`teams` (`city`, `name`, `stadium`, `league_id`)
VALUES ('New York', 'Giants', 'Metlife Stadium', 1);

INSERT INTO `final_project`.`teams` (`city`, `name`, `stadium`, `league_id`)
VALUES ('Kansas City', 'Chiefs', 'Arrowhead Stadium', 1);

INSERT INTO `final_project`.`teams` (`city`, `name`, `stadium`, `league_id`)
VALUES ('BC', 'Lions', 'BC Place', 2);

INSERT INTO `final_project`.`teams` (`city`, `name`, `stadium`, `league_id`)
VALUES ('Seattle', 'Dragons', 'Lumen Field', 3);

-- insert data into staff

INSERT INTO `final_project`.`staff`(`name`,`role`,`salary`,`team`)
VALUES('Nigel', 'Medic', 100, 1);

-- insert data into players

INSERT INTO `final_project`.`players`
(`first_name`,`last_name`,`position`,`dob`,`team_id`,`username`,`password`)
VALUES('Candace','Owens','QB','2000-07-06', 4, '@RealCandaceO', 'password1');


