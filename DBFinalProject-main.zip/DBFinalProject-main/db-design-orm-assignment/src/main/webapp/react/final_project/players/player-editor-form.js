import playerService from "./player-service"

const {useState, useEffect} = React
const {useParams, useHistory} = window.ReactRouterDOM;

const PlayerEditorForm = () => {
    const [player, setPlayer] = useState({})
    const {playerId} = useParams()
    const history = useHistory()
    useEffect(() => {
        findPlayerById(playerId)
    }, []);
    const findPlayerById = (id) =>
        playerService.findPlayerById(id)
            .then(player => setPlayer(player))
    const updatePlayer = (id, newPlayer) =>
        playerService.updatePlayer(id, newPlayer)
            .then(() => history.goBack())
    const deletePlayer = (id) =>
        playerService.deletePlayer(id)
            .then(() => history.goBack())
    
    return (
        <div>
            <h2>
                Player Editor
            </h2>
            <label>Id</label>
            <input
                className="form-control margin-bottom-10px"
                readOnly={true}
                value={player.id}/>
            <label>First Name</label>
            <input
                className="form-control margin-bottom-10px"
                onChange={(e) => setPlayer(player => ({...player, firstName: e.target.value}))}
                value={player.firstName}/>
            <label>Last Name</label>
            <input
                className="form-control margin-bottom-10px"
                onChange={(e) => setPlayer(player => ({...player, lastName: e.target.value}))}
                value={player.lastName}/>
            <label>Position</label>
            <select
                className="form-control margin-bottom-10px"
                value={player.position}
                onChange={(e)=>setPlayer(player => ({...player, position: e.target.value}))}>
                <option>QB</option>
                <option>RB</option>
                <option>FB</option>
                <option>WR</option>
                <option>TE</option>
                <option>LT</option>
                <option>LG</option>
                <option>C</option>
                <option>RG</option>
                <option>RT</option>
                <option>LE</option>
                <option>DT</option>
                <option>RE</option>
                <option>LOLB</option>
                <option>MLB</option>
                <option>ROLB</option>
                <option>CB</option>
                <option>FS</option>
                <option>SS</option>
                <option>K</option>
                <option>P</option>
            </select>
            <label>DOB</label>
            <input
                className="form-control margin-bottom-10px"
                value={player.dob}
                onChange={(e)=>setPlayer(player => ({...player, dob: e.target.value}))}/>
            <label>Team</label>
            <input
                className="form-control margin-bottom-10px"
                value={player.team}
                onChange={(e)=>setPlayer(player => ({...player, team: e.target.value}))}/>
            <label>Email</label>
            <input
                className="form-control margin-bottom-10px"
                value={player.email}
                onChange={(e)=>setPlayer(player => ({...player, email: e.target.value}))}/>
            <label>Username</label>
            <input
                className="form-control margin-bottom-10px"
                value={player.username}
                onChange={(e)=>setPlayer(player => ({...player, username: e.target.value}))}/>
            <label>Password</label>
            <input
                className="form-control margin-bottom-10px"
                value={player.password}
                onChange={(e)=>setPlayer(player => ({...player, password: e.target.value}))}/>
            <br/>
            <button
                onClick={() => updatePlayer(player.id, player)}
                className="btn btn-success btn-block">Save</button>
            <button
                onClick={() => {
                    history.goBack()
                }}
                className="btn btn-danger btn-block margin-left-10px">Cancel</button>
            <button
                onClick={() => deletePlayer(player.id)}
                className="btn btn-danger btn-block margin-left-10px">Delete</button>
        </div>
    )
}

export default PlayerEditorForm