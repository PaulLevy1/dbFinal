const LEAGUE_URL = "http://localhost:8080/api/leagues"

export const createLeague = (league) =>
    fetch(LEAGUE_URL, {
        method: 'POST',
        body: JSON.stringify(league),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export const findAllLeagues = () =>
    fetch(LEAGUE_URL)
        .then(response => response.json())

export const findLeagueById = (id) =>
    fetch(`${LEAGUE_URL}/${id}`)
        .then(response => response.json())

export const updateLeague = (id, league) =>
    fetch(`${LEAGUE_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(league),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export const deleteLeague = (id) =>
    fetch(`${LEAGUE_URL}/${id}`, {
        method: "DELETE"
    })

export default {
    createLeague,
    findAllLeagues,
    findLeagueById,
    updateLeague,
    deleteLeague
}